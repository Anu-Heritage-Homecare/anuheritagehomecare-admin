import { useEffect, useMemo, useState } from 'react'
import { Link, useNavigate, useParams, useSearchParams } from 'react-router-dom'
import { SelectFilter } from '@/components/ui/SelectFilter'
import { cn } from '@/lib/cn'
import {
  allThreads,
  lastMessage,
  searchThreads,
  sortOptions,
  sortThreads,
  threadContext,
  useMessageRevision,
} from '@/features/messages/data'
import type { Thread, ThreadSort } from '@/features/messages/data'
import {
  allNotices,
  searchNotices,
  sortNotices,
} from '@/features/messages/notices'
import type { Notice } from '@/features/messages/notices'
import { markRead, useReadState } from '@/features/messages/read-state'
import { ComposeDialog } from '@/features/messages/ComposeDialog'
import { ConversationDetails } from '@/features/messages/ConversationDetails'
import { useThreadFlags } from '@/features/messages/flags'
import {
  folderCounts,
  folderLabels,
  isNoticeFolder,
  noticesIn,
  readFolder,
  threadsIn,
} from '@/features/messages/folders'
import { FolderRail } from '@/features/messages/FolderRail'
import { NoticeRow, ThreadRow } from '@/features/messages/InboxList'
import { NoticePane } from '@/features/messages/NoticePane'
import { ThreadPane } from '@/features/messages/ThreadPane'

/**
 * Three panes on a wide screen, one on a narrow one.
 *
 * The open conversation is a route rather than component state, so a thread can
 * be linked to and Back leaves it. The folder, the search and the sort are
 * query parameters on that route for the same reason — and because the rail has
 * to survive opening a message and coming back.
 */
export function MessagesPage() {
  const { entryId } = useParams()
  const navigate = useNavigate()
  const [params, setParams] = useSearchParams()
  const [composing, setComposing] = useState(false)

  // Rebuilds when anything is sent, on either store.
  const revision = useMessageRevision()
  // And when something is opened: the Unread folder counts off this.
  const reads = useReadState()
  // Archiving or muting moves what the folders hold.
  const flags = useThreadFlags()

  const folder = readFolder(params.get('folder'))
  const query = params.get('q') ?? ''
  const sort = (sortOptions.find((o) => o.value === params.get('sort'))
    ?.value ?? 'recent') as ThreadSort

  const setParam = (key: string, value: string | null) => {
    const next = new URLSearchParams(params)
    if (value) next.set(key, value)
    else next.delete(key)
    // Only keystrokes replace. Picking a folder or a sort is a decision, so
    // Back undoes it.
    setParams(next, { replace: key === 'q' })
  }

  /*
   * `revision` is the dependency: `allThreads()` reads two module-level stores
   * rather than props, and the revision is what says they have moved. ESLint
   * cannot see that from the call.
   */
  // eslint-disable-next-line react-hooks/exhaustive-deps
  const threads = useMemo(() => allThreads(), [revision])
  const notices = useMemo(() => allNotices(), [])

  /*
   * Searched before the folder is applied, so the rail counts what the search
   * left rather than advertising thirteen above a list showing one.
   */
  const searchedThreads = useMemo(
    () => searchThreads(threads, query),
    [threads, query],
  )
  const searchedNotices = useMemo(
    () => searchNotices(notices, query),
    [notices, query],
  )
  /*
   * `reads` is the dependency ESLint cannot see: folderCounts calls isRead on
   * a module-level store rather than reading anything passed in, and the
   * revision is what says that store has moved.
   */
  const counts = useMemo(
    () => folderCounts(searchedThreads, searchedNotices),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [searchedThreads, searchedNotices, reads, flags],
  )

  const showingNotices = isNoticeFolder(folder)
  const threadRows = useMemo(
    () => sortThreads(threadsIn(folder, searchedThreads), sort),
    [folder, searchedThreads, sort],
  )
  const noticeRows = useMemo(
    () => sortNotices(noticesIn(folder, searchedNotices)),
    [folder, searchedNotices],
  )
  // All and Unread hold both kinds, so the list is one run sorted by when
  // something last happened on it rather than two stacked lists.
  const mixed = folder === 'all' || folder === 'unread'
  const rows = useMemo(() => {
    const items: {
      id: string
      at: string
      thread?: Thread
      notice?: Notice
    }[] = [
      ...threadRows.map((thread) => ({
        id: thread.id,
        at: lastMessage(thread)?.at ?? '',
        thread,
      })),
      ...noticeRows.map((notice) => ({ id: notice.id, at: notice.at, notice })),
    ]
    return mixed ? items.sort((a, b) => b.at.localeCompare(a.at)) : items
  }, [threadRows, noticeRows, mixed])
  const rowCount = rows.length

  // Opening it is what marks it read, so the rail moves as you work down the
  // list rather than when a message is answered.
  useEffect(() => {
    if (entryId) markRead(entryId)
  }, [entryId])

  const openThread = threads.find((t) => t.id === entryId)
  const openNotice = notices.find((n) => n.id === entryId)
  const open = Boolean(openThread || openNotice)

  const search = new URLSearchParams({
    ...(folder !== 'all' ? { folder } : {}),
    ...(query ? { q: query } : {}),
    ...(sort !== 'recent' ? { sort } : {}),
  }).toString()
  const suffix = search ? `?${search}` : ''
  const linkTo = (id: string) => `/messages/${id}${suffix}`

  // The open item can sit in another folder or outside the search. Saying so
  // beats a highlighted row the reader cannot find.
  const hidden = open && !rows.some((r) => r.id === entryId)

  return (
    <div className="space-y-5">
      {/*
       * Two layouts on one route. With nothing open it is the inbox: the
       * folder rail and the list. Open a conversation and the conversation
       * takes the page, with its own details panel beside it — the list is a
       * back arrow away, and reading a thread in a third of the width was the
       * worst of both.
       */}
      <div
        className={cn(
          'grid gap-4 lg:items-start',
          open
            ? 'lg:grid-cols-[minmax(0,1fr)_20rem]'
            : 'lg:grid-cols-[17rem_minmax(0,1fr)]',
        )}
      >
        <div className={cn('min-w-0 lg:sticky lg:top-6', open && 'hidden')}>
          <FolderRail
            folder={folder}
            counts={counts}
            onSelect={(next) =>
              setParam('folder', next === 'all' ? null : next)
            }
            onCompose={() => setComposing(true)}
          />
        </div>

        {/* On the narrow layout the list and the open item share one column. */}
        <section
          aria-label={folderLabels[folder]}
          className={cn(
            'card flex min-h-0 min-w-0 flex-col lg:h-[calc(100dvh-10rem)] lg:min-h-[32rem]',
            open && 'hidden lg:hidden',
          )}
        >
          <div className="space-y-2.5 p-3">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <h2 className="text-ink text-lg font-bold tracking-tight">
                {folder === 'all' ? 'Inbox' : folderLabels[folder]}
              </h2>
              {!showingNotices && (
                <SelectFilter
                  chip
                  valueOnly
                  value={sort}
                  onChange={(v) => setParam('sort', v === 'recent' ? null : v)}
                  options={sortOptions}
                  label="Sort"
                />
              )}
            </div>
            {/* The design has no search in this header — the rail's box
                searches the folders. Commented rather than deleted: the `q`
                parameter, `searchThreads` and `searchNotices` all still work,
                so a saved link that carries one keeps filtering the list, and
                putting the box back is uncommenting it.

            <label className="block">
              <span className="sr-only">Search messages</span>
              <input
                type="search"
                value={query}
                onChange={(e) => setParam('q', e.target.value)}
                placeholder="Search people, clients or message text"
                className="border-line focus:border-brand-500 h-10 w-full rounded-lg border px-3 text-sm"
              />
            </label>
            */}
          </div>

          {hidden && (
            <p className="border-brand-200 bg-brand-50 text-brand-800 m-3 rounded-lg border px-3 py-2 text-xs">
              What you have open is not in this folder.{' '}
              <Link
                to={`/messages/${entryId}`}
                className="font-semibold underline"
              >
                Clear the filters
              </Link>{' '}
              to see its row.
            </p>
          )}

          {rowCount === 0 ? (
            <p
              role="status"
              className="text-ink-subtle px-4 py-12 text-center text-sm"
            >
              Nothing here matches.
            </p>
          ) : (
            <ul className="min-h-0 flex-1 space-y-2 overflow-y-auto px-3 pb-3">
              {rows.map((row) =>
                row.thread ? (
                  <ThreadRow
                    key={row.id}
                    thread={row.thread}
                    to={linkTo(row.id)}
                    selected={row.id === entryId}
                  />
                ) : (
                  <NoticeRow
                    key={row.id}
                    notice={row.notice!}
                    to={linkTo(row.id)}
                    selected={row.id === entryId}
                  />
                ),
              )}
            </ul>
          )}
        </section>

        <div
          className={cn(
            'min-h-0 min-w-0 lg:h-[calc(100dvh-10rem)] lg:min-h-[32rem]',
            !open && 'hidden',
          )}
        >
          {openThread ? (
            <ThreadPane thread={openThread} backTo={`/messages${suffix}`} />
          ) : openNotice ? (
            <NoticePane notice={openNotice} backTo={`/messages${suffix}`} />
          ) : (
            <div />
          )}
        </div>

        {openThread && (
          <div className="min-h-0 min-w-0 lg:h-[calc(100dvh-10rem)] lg:min-h-[32rem]">
            <ConversationDetails
              thread={openThread}
              context={
                openThread.about
                  ? threadContext(openThread.about.id)
                  : undefined
              }
            />
          </div>
        )}
      </div>

      {composing && (
        <ComposeDialog
          onClose={() => setComposing(false)}
          onSent={(threadId) => {
            setComposing(false)
            navigate(`/messages/${threadId}`)
          }}
        />
      )}
    </div>
  )
}
