import { Link } from 'react-router-dom'
import {
  Archive,
  ArchiveRestore,
  BellOff,
  ClipboardList,
  Download,
  Paperclip,
} from 'lucide-react'
import { Avatar } from '@/components/ui/Avatar'
import { SIGNED_IN, SIGNED_IN_ROLE } from '@/lib/session'
import { cn } from '@/lib/cn'
import { formatClock, formatThreadDay, onVisitNow, threadStatus } from './data'
import type { Thread, ThreadContext } from './data'
import {
  isArchived,
  isMuted,
  setArchived,
  setMuted,
  useThreadFlags,
} from './flags'

/**
 * The conversation's own panel: who is on it, what it is about, what has been
 * sent through it, and the two things a coordinator can do to it.
 *
 * Everything here is read off the thread and the care record — there is no
 * per-conversation store behind it beyond the two flags at the bottom.
 */
export function ConversationDetails({
  thread,
  context,
}: {
  thread: Thread
  context: ThreadContext | undefined
}) {
  useThreadFlags()
  const archived = isArchived(thread.id)
  const muted = isMuted(thread.id)
  const files = thread.messages.filter((m) => m.attachment)
  const status = threadStatus(thread)

  return (
    <aside
      aria-label="Conversation details"
      className="card flex min-h-0 flex-col overflow-y-auto lg:h-full"
    >
      <h2 className="text-ink border-line border-b px-4 py-3 text-sm font-bold tracking-tight">
        Conversation Details
      </h2>

      <div className="space-y-5 p-4">
        <Section title="Participants">
          <ul className="space-y-2.5">
            <Participant
              name={thread.name}
              role={
                status
                  ? `Caregiver (${
                      status === 'active'
                        ? onVisitNow(thread)
                          ? 'Active, on a visit now'
                          : 'Active'
                        : status === 'on-leave'
                          ? 'On leave'
                          : 'Not active'
                    })`
                  : thread.role
              }
              to={thread.to}
            />
            <Participant name={SIGNED_IN} role={`${SIGNED_IN_ROLE} (You)`} />
          </ul>
        </Section>

        {context && (
          <Section title="Linked record">
            <div className="bg-canvas rounded-xl p-3">
              <p className="flex items-center gap-2">
                <ClipboardList
                  className="text-brand-600 size-4 shrink-0"
                  strokeWidth={1.9}
                  aria-hidden="true"
                />
                <span className="text-ink min-w-0 text-sm font-semibold break-words">
                  {context.recipient.name}
                </span>
              </p>
              <p className="mt-1.5 flex flex-wrap items-center justify-between gap-2">
                <span className="text-ink-subtle text-xs">Care recipient</span>
                <Link
                  to={`/care-recipients/${context.recipient.id}/${
                    context.hasCarePlan ? 'care-plan' : 'overview'
                  }`}
                  className="text-brand-700 text-xs font-semibold hover:underline"
                >
                  {context.hasCarePlan ? 'View plan' : 'View profile'}
                </Link>
              </p>
              {/* Read off the plan. An empty list says so rather than leaving
                  the line to be read as "none known". */}
              <p className="text-ink-muted mt-2 text-xs break-words">
                {context.medications.length > 0
                  ? `Medication: ${context.medications.join(', ')}`
                  : context.hasMedicationPlan
                    ? 'Medication: nothing on the plan'
                    : 'No medication plan on this record'}
              </p>
            </div>
          </Section>
        )}

        {context?.next && (
          <Section title="Linked visit">
            <div className="bg-canvas rounded-xl p-3">
              <p className="flex flex-wrap items-center justify-between gap-2">
                <Link
                  to={`/scheduling/visits/${context.next.id}`}
                  className="text-ink hover:text-brand-700 text-sm font-semibold"
                >
                  {context.next.reference}
                </Link>
                <span className="text-brand-700 text-xs font-semibold">
                  {context.next.type}
                </span>
              </p>
              <p className="text-ink-muted mt-1 text-xs">
                {formatThreadDay(context.next.date)},{' '}
                {formatClock(context.next.start)} —{' '}
                {context.next.caregiverName ?? 'nobody assigned yet'}
              </p>
            </div>
          </Section>
        )}

        <Section
          title={`Shared files${files.length > 0 ? ` (${files.length})` : ''}`}
        >
          {files.length === 0 ? (
            <p className="text-ink-subtle text-xs">
              Nothing has been attached to this conversation.
            </p>
          ) : (
            <ul className="space-y-2">
              {files.map((message) => (
                <li key={message.id}>
                  <a
                    href={message.attachment!.url}
                    download={message.attachment!.name}
                    className="hover:bg-canvas flex items-center gap-2 rounded-lg p-1.5"
                  >
                    <Paperclip
                      className="text-ink-subtle size-4 shrink-0"
                      strokeWidth={1.9}
                      aria-hidden="true"
                    />
                    <span className="min-w-0 flex-1">
                      <span className="text-ink block truncate text-xs font-medium">
                        {message.attachment!.name}
                      </span>
                      <span className="text-ink-subtle block text-[0.6875rem]">
                        {fileSize(message.attachment!.size)} · {message.author}
                      </span>
                    </span>
                    <Download
                      className="text-ink-subtle size-4 shrink-0"
                      strokeWidth={1.9}
                      aria-hidden="true"
                    />
                  </a>
                </li>
              ))}
            </ul>
          )}
        </Section>

        <Section title="Quick actions">
          {/* Two, both of which change what the folders show. The design's
              third is "Leave conversation": the agency is a party to every one
              of these, so there is no membership to leave. */}
          <div className="grid grid-cols-2 gap-2">
            <Action
              icon={archived ? ArchiveRestore : Archive}
              label={archived ? 'Restore' : 'Archive'}
              onClick={() => setArchived(thread.id, !archived)}
            />
            <Action
              icon={BellOff}
              label={muted ? 'Unmute' : 'Mute'}
              active={muted}
              onClick={() => setMuted(thread.id, !muted)}
            />
          </div>
          <p className="text-ink-subtle mt-2 text-[0.6875rem]">
            {archived
              ? 'Out of every folder. Still here on its own link.'
              : muted
                ? 'Stays in the folders, out of the Unread count.'
                : 'Archive takes it out of the folders; mute keeps it out of Unread.'}
          </p>
        </Section>
      </div>
    </aside>
  )
}

function Section({
  title,
  children,
}: {
  title: string
  children: React.ReactNode
}) {
  return (
    <section>
      <h3 className="text-ink-subtle text-[0.6875rem] font-semibold tracking-wider uppercase">
        {title}
      </h3>
      <div className="mt-2">{children}</div>
    </section>
  )
}

function Participant({
  name,
  role,
  to,
}: {
  name: string
  role: string
  to?: string
}) {
  const body = (
    <>
      <Avatar name={name} decorative className="size-8 text-[0.6875rem]" />
      <span className="min-w-0">
        <span className="text-ink block truncate text-sm font-semibold">
          {name}
        </span>
        <span className="text-ink-subtle block truncate text-xs">{role}</span>
      </span>
    </>
  )

  return (
    <li>
      {to ? (
        <Link
          to={to}
          className="hover:bg-canvas flex items-center gap-2.5 rounded-lg p-1"
        >
          {body}
        </Link>
      ) : (
        <span className="flex items-center gap-2.5 p-1">{body}</span>
      )}
    </li>
  )
}

function Action({
  icon: Icon,
  label,
  active = false,
  onClick,
}: {
  icon: typeof Archive
  label: string
  active?: boolean
  onClick: () => void
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        'inline-flex min-h-10 items-center justify-center gap-1.5 rounded-lg border px-2 text-xs font-medium',
        active
          ? 'border-brand-600 bg-brand-50 text-brand-700'
          : 'border-line text-ink hover:bg-sunken',
      )}
    >
      <Icon className="size-4 shrink-0" strokeWidth={1.9} aria-hidden="true" />
      {label}
    </button>
  )
}

/** "24 KB" — enough to tell a photo from a form before opening it. */
function fileSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`
  if (bytes < 1024 * 1024) return `${Math.round(bytes / 1024)} KB`
  return `${(bytes / 1024 / 1024).toFixed(1)} MB`
}
