/**
 * Per-thread flags a coordinator sets: archived and muted.
 *
 * Archived takes a conversation out of the folders without deleting anything —
 * the thread is still there on its own URL, and the details panel offers it
 * back. Muted leaves it in the folders but keeps it out of the Unread count,
 * for a thread somebody is working through and does not want chased about.
 *
 * Held in memory for the session, like everything else this app writes.
 */
import { useSyncExternalStore } from 'react'

const archived = new Set<string>()
const muted = new Set<string>()
let revision = 0
const listeners = new Set<() => void>()

function emit(): void {
  revision += 1
  for (const listener of listeners) listener()
}

function subscribe(listener: () => void): () => void {
  listeners.add(listener)
  return () => listeners.delete(listener)
}

export function useThreadFlags(): number {
  return useSyncExternalStore(
    subscribe,
    () => revision,
    () => revision,
  )
}

export function isArchived(id: string): boolean {
  return archived.has(id)
}

export function isMuted(id: string): boolean {
  return muted.has(id)
}

export function setArchived(id: string, value: boolean): void {
  if (value) archived.add(id)
  else archived.delete(id)
  emit()
}

export function setMuted(id: string, value: boolean): void {
  if (value) muted.add(id)
  else muted.delete(id)
  emit()
}
