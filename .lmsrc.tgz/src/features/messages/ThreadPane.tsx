import { useEffect, useRef, useState } from 'react'
import { Link } from 'react-router-dom'
import {
  ArrowLeft,
  ArrowRight,
  Paperclip,
  Phone,
  Search,
  Video,
  X,
} from 'lucide-react'
import { Avatar } from '@/components/ui/Avatar'
import { DropdownMenu } from '@/components/ui/DropdownMenu'
import { Drawer } from '@/components/ui/Drawer'
import { SIGNED_IN } from '@/lib/session'
import { cn } from '@/lib/cn'
import { tonePill } from '@/lib/tone'
import { telHref } from '@/features/monitoring/live-data'
import {
  formatClock,
  formatThreadDay,
  logCall,
  onVisitNow,
  sendMessage,
  threadStatus,
} from './data'
import type { Attachment, ContactMark, Message, Thread } from './data'

/* --------------------------------- rows ----------------------------------- */

type Row =
  | { kind: 'day'; key: string; at: string }
  | { kind: 'message'; key: string; message: Message }
  | { kind: 'mark'; key: string; mark: ContactMark }

/**
 * Messages and logged contacts in one column, cut into days.
 *
 * A contact with no clock sorts to the head of its day rather than being given
 * a time to sort by — the log records which day somebody rang, and nothing
 * more.
 */
function rowsFor(thread: Thread): Row[] {
  const entries: { at: string; time: string; row: Row }[] = [
    ...thread.messages.map((message) => ({
      at: message.at,
      time: message.time ?? '00:00',
      row: { kind: 'message', key: message.id, message } as Row,
    })),
    ...thread.marks.map((mark) => ({
      at: mark.at,
      time: '00:00',
      row: { kind: 'mark', key: mark.id, mark } as Row,
    })),
  ].sort((a, b) => a.at.localeCompare(b.at) || a.time.localeCompare(b.time))

  const rows: Row[] = []
  let day: string | null = null
  for (const entry of entries) {
    if (entry.at !== day) {
      day = entry.at
      rows.push({ kind: 'day', key: `day-${entry.at}`, at: entry.at })
    }
    rows.push(entry.row)
  }
  return rows
}

/* -------------------------------- the pane -------------------------------- */

export function ThreadPane({
  thread,
  backTo,
}: {
  thread: Thread
  /** Returns to the list on the narrow layout, where the two share the column. */
  backTo: string
}) {
  const onVisit = onVisitNow(thread)
  const status = threadStatus(thread)
  const [finding, setFinding] = useState(false)
  const [needle, setNeedle] = useState('')
  const [calling, setCalling] = useState(false)
  const log = useRef<HTMLDivElement>(null)

  /*
   * Open on the latest message, not the oldest. Keyed on the thread and the
   * message count, so switching conversation and sending both land at the
   * bottom — a thread that opened at the top of a year-old exchange read as
   * having nothing recent in it.
   */
  useEffect(() => {
    const panel = log.current
    if (panel) panel.scrollTop = panel.scrollHeight
  }, [thread.id, thread.messages.length])

  /*
   * Filtered on the message, then the days re-cut around what is left — a day
   * separator over nothing is how a filtered thread looks like a broken one.
   */
  const term = needle.trim().toLowerCase()
  const shown =
    term === ''
      ? thread
      : {
          ...thread,
          messages: thread.messages.filter((m) =>
            m.body.toLowerCase().includes(term),
          ),
          marks: thread.marks.filter((m) =>
            m.subject.toLowerCase().includes(term),
          ),
        }
  const rows = rowsFor(shown)
  const matches = shown.messages.length + shown.marks.length

  return (
    <section
      aria-label={`Conversation with ${thread.name}`}
      className="card flex min-h-0 flex-col lg:h-full"
    >
      <header className="border-line flex flex-wrap items-center gap-3 border-b p-4">
        <Link
          to={backTo}
          className="text-ink-muted hover:text-ink -ml-1 inline-flex size-9 shrink-0 items-center justify-center rounded-lg"
        >
          <ArrowLeft className="size-4" strokeWidth={2} aria-hidden="true" />
          <span className="sr-only">Back to the inbox</span>
        </Link>
        <span className="relative shrink-0">
          <Avatar name={thread.name} decorative className="size-11 text-sm" />
          {/* The design's green dot. "Online" is not something this app
              records — nothing here knows who is signed in — so the dot shows
              the standing the roster keeps, and says when the board also has
              them out on a visit. */}
          {status && (
            <span
              className={cn(
                'border-surface absolute right-0 bottom-0 size-3 rounded-full border-2',
                status === 'active'
                  ? 'bg-emerald-500'
                  : status === 'on-leave'
                    ? 'bg-amber-400'
                    : 'bg-slate-300',
              )}
              title={
                status === 'active'
                  ? onVisit
                    ? `${thread.name} is active, and on a visit now`
                    : `${thread.name} is active on the roster`
                  : status === 'on-leave'
                    ? `${thread.name} is on leave`
                    : `${thread.name} is not active`
              }
            >
              <span className="sr-only">
                {status === 'active'
                  ? onVisit
                    ? 'Active, on a visit now'
                    : 'Active'
                  : status === 'on-leave'
                    ? 'On leave'
                    : 'Not active'}
              </span>
            </span>
          )}
        </span>
        <div className="min-w-0 flex-1">
          <span className="flex flex-wrap items-center gap-2">
            <h2 className="text-ink truncate text-base font-bold tracking-tight">
              {thread.name}
            </h2>
            <span
              className={cn(
                'inline-flex shrink-0 items-center rounded-full px-1.5 py-0.5 text-[0.6875rem] font-semibold whitespace-nowrap',
                thread.kind === 'caregiver' ? tonePill.green : tonePill.blue,
              )}
            >
              {thread.kind === 'caregiver' ? 'Caregiver' : 'Family'}
            </span>
          </span>
          <p className="text-ink-subtle mt-0.5 text-xs break-words">
            {thread.about ? (
              <>
                {'Linked: '}
                <Link
                  to={`/care-recipients/${thread.about.id}/overview`}
                  className="text-brand-700 hover:underline"
                >
                  {thread.about.name}
                </Link>
                {' (Care Recipient)'}
              </>
            ) : (
              thread.role
            )}
          </p>
        </div>
        <div className="flex items-center gap-2">
          {/*
           * Square buttons, as the design draws them. The phone dials, because
           * a number is the one contact detail every one of these people
           * carries. Nothing here places a video call — there is no service
           * behind it — so that button records one instead, which is a thing
           * this app genuinely keeps.
           */}
          {/* Searches this conversation, not the inbox: the rows below are
              filtered to the messages that carry the words. */}
          <button
            type="button"
            onClick={() => {
              setFinding((open) => !open)
              if (finding) setNeedle('')
            }}
            aria-expanded={finding}
            title={`Search this conversation`}
            className={cn(
              'grid size-10 place-items-center rounded-lg border',
              finding
                ? 'border-brand-600 bg-brand-50 text-brand-700'
                : 'border-line text-ink hover:bg-sunken',
            )}
          >
            <Search className="size-4.5" strokeWidth={1.9} aria-hidden="true" />
            <span className="sr-only">Search this conversation</span>
          </button>
          <a
            href={telHref(thread.phone)}
            title={`Call ${thread.name} on ${thread.phone}`}
            className="border-line text-ink hover:bg-sunken grid size-10 place-items-center rounded-lg border"
          >
            <Phone className="size-4.5" strokeWidth={1.9} aria-hidden="true" />
            <span className="sr-only">Call {thread.name}</span>
          </a>
          <button
            type="button"
            onClick={() => setCalling(true)}
            title={`Record a video call with ${thread.name}`}
            className="border-line text-ink hover:bg-sunken grid size-10 place-items-center rounded-lg border"
          >
            <Video className="size-4.5" strokeWidth={1.9} aria-hidden="true" />
            <span className="sr-only">
              Record a video call with {thread.name}
            </span>
          </button>
          <DropdownMenu
            bordered
            label={`More for ${thread.name}`}
            items={[
              {
                id: 'record',
                label:
                  thread.kind === 'caregiver'
                    ? 'Open caregiver record'
                    : 'Open family record',
                to: thread.to,
              },
              ...(thread.about
                ? [
                    {
                      id: 'client',
                      label: `Open ${thread.about.name}'s record`,
                      to: `/care-recipients/${thread.about.id}/overview`,
                    },
                  ]
                : []),
            ]}
          />
        </div>
      </header>

      {thread.kind === 'family' && thread.about && (
        <p className="border-line bg-sunken text-ink-muted border-b px-4 py-2.5 text-xs">
          This thread is the communication log on{' '}
          <Link
            to={`/care-recipients/${thread.about.id}/family`}
            className="text-brand-700 font-medium hover:underline"
          >
            {thread.about.name}&rsquo;s record
          </Link>
          . The log keeps a subject line and the day it happened, so these carry
          no time of day.
        </p>
      )}

      {finding && (
        <div className="border-line border-b p-3">
          <label className="block">
            <span className="sr-only">Search this conversation</span>
            <input
              type="search"
              autoFocus
              value={needle}
              onChange={(e) => setNeedle(e.target.value)}
              placeholder={`Search this conversation`}
              className="border-line focus:border-brand-500 h-10 w-full rounded-lg border px-3 text-sm"
            />
          </label>
          {needle.trim() !== '' && (
            <p role="status" className="text-ink-subtle mt-1.5 text-xs">
              {matches} message{matches === 1 ? '' : 's'} match.
            </p>
          )}
        </div>
      )}

      <div ref={log} className="min-h-0 flex-1 space-y-4 overflow-y-auto p-4">
        {rows.map((row) => {
          if (row.kind === 'day')
            return <DaySeparator key={row.key} at={row.at} />
          if (row.kind === 'mark') return <Mark key={row.key} mark={row.mark} />
          return <Bubble key={row.key} message={row.message} />
        })}
      </div>

      <Composer thread={thread} />

      {calling && (
        <LogCallDialog thread={thread} onClose={() => setCalling(false)} />
      )}
    </section>
  )
}

/* --------------------------------- pieces --------------------------------- */

function DaySeparator({ at }: { at: string }) {
  return (
    <div className="flex items-center gap-3">
      <span aria-hidden="true" className="bg-line h-px flex-1" />
      <span className="text-ink-subtle text-xs font-semibold">
        {formatThreadDay(at)}
      </span>
      <span aria-hidden="true" className="bg-line h-px flex-1" />
    </div>
  )
}

function Bubble({ message }: { message: Message }) {
  const outbound = message.direction === 'outbound'

  return (
    <div
      className={cn('flex flex-col', outbound ? 'items-end' : 'items-start')}
    >
      <p className="mb-1.5 flex flex-wrap items-baseline gap-2">
        <span className="text-ink text-sm font-bold">
          {outbound && message.author === SIGNED_IN
            ? `${message.author} (Me)`
            : message.author}
        </span>
        {message.time && (
          <span className="text-ink-subtle text-xs">
            {formatClock(message.time)}
          </span>
        )}
        {message.channel !== 'App Message' && (
          <span className="text-ink-subtle text-xs">{message.channel}</span>
        )}
      </p>
      <p
        className={cn(
          'max-w-[85%] rounded-2xl px-4 py-3 text-sm break-words sm:max-w-[38rem]',
          outbound ? 'bg-brand-600 text-white' : 'bg-canvas text-ink',
          // A subject line off the log is a record of a message, not the
          // message. Rendering it as if it were the words somebody typed is
          // the one thing this thread must not do.
          message.fromLog && 'italic',
        )}
      >
        {message.body}
      </p>
      {message.attachment && (
        <a
          href={message.attachment.url}
          download={message.attachment.name}
          className="border-line hover:bg-sunken mt-1.5 inline-flex max-w-[85%] items-center gap-2 rounded-lg border px-3 py-2 text-xs"
        >
          <Paperclip
            className="text-ink-subtle size-3.5 shrink-0"
            strokeWidth={1.9}
            aria-hidden="true"
          />
          <span className="text-ink min-w-0 truncate font-medium">
            {message.attachment.name}
          </span>
          <span className="text-ink-subtle shrink-0">
            {fileSize(message.attachment.size)}
          </span>
        </a>
      )}
    </div>
  )
}

function Mark({ mark }: { mark: ContactMark }) {
  return (
    <p className="text-ink-subtle text-center text-xs">
      {mark.type} logged — &ldquo;{mark.subject}&rdquo;, {mark.staff}
    </p>
  )
}

/**
 * Recording a call that has happened.
 *
 * The button it sits behind is where the design puts "start a video call".
 * Nothing in this app can place one, so this writes the contact down: on a
 * family thread it joins the communication log on the care record, and on a
 * caregiver thread it joins the conversation.
 */
function LogCallDialog({
  thread,
  onClose,
}: {
  thread: Thread
  onClose: () => void
}) {
  const [note, setNote] = useState('')

  return (
    <Drawer
      open
      onClose={onClose}
      placement="center"
      title="Record a video call"
      subtitle={thread.name}
    >
      <div className="space-y-4 p-4 sm:p-5">
        <p className="text-ink-muted text-sm">
          There is no video service behind this button. Writing the call down is
          what the app can do with it —{' '}
          {thread.kind === 'family'
            ? 'it joins the communication log on the care record.'
            : 'it joins this conversation as a logged contact.'}
        </p>
        <label className="block">
          <span className="text-ink text-sm font-medium">
            What it was about{' '}
            <span className="text-ink-subtle font-normal">(optional)</span>
          </span>
          <input
            type="text"
            value={note}
            onChange={(e) => setNote(e.target.value)}
            placeholder={`Video call with ${thread.name}`}
            className="border-line focus:border-brand-500 mt-1.5 h-11 w-full rounded-lg border px-3 text-sm"
          />
        </label>
        <div className="flex flex-wrap justify-end gap-2">
          <button
            type="button"
            onClick={onClose}
            className="border-control text-ink hover:bg-sunken inline-flex min-h-11 items-center rounded-lg border px-4 text-sm font-medium"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={() => {
              logCall(thread, 'Video Call', note)
              onClose()
            }}
            className="bg-brand-600 hover:bg-brand-700 inline-flex min-h-11 items-center rounded-lg px-4 text-sm font-semibold text-white"
          >
            Record the call
          </button>
        </div>
      </div>
    </Drawer>
  )
}

function Composer({ thread }: { thread: Thread }) {
  const [draft, setDraft] = useState('')
  const [file, setFile] = useState<Attachment | null>(null)
  const picker = useRef<HTMLInputElement>(null)
  const empty = draft.trim() === '' && !file
  const first = thread.name.split(' ')[0]

  return (
    <form
      className="p-4"
      onSubmit={(e) => {
        e.preventDefault()
        if (empty) return
        sendMessage(thread, draft, file ?? undefined)
        setDraft('')
        setFile(null)
      }}
    >
      {file && (
        <p className="border-line mb-2 inline-flex max-w-full items-center gap-2 rounded-lg border px-3 py-1.5 text-xs">
          <Paperclip
            className="text-ink-subtle size-3.5 shrink-0"
            strokeWidth={1.9}
            aria-hidden="true"
          />
          <span className="text-ink min-w-0 truncate font-medium">
            {file.name}
          </span>
          <span className="text-ink-subtle shrink-0">
            {fileSize(file.size)}
          </span>
          <button
            type="button"
            onClick={() => {
              URL.revokeObjectURL(file.url)
              setFile(null)
            }}
            className="text-ink-subtle hover:text-ink shrink-0"
          >
            <X className="size-3.5" strokeWidth={2} aria-hidden="true" />
            <span className="sr-only">Remove {file.name}</span>
          </button>
        </p>
      )}

      <div className="border-line focus-within:border-brand-500 flex items-end gap-2 rounded-2xl border p-2 pl-2.5">
        {/*
         * A real file, kept where it was picked. There is no server to put it
         * on, so the browser holds the bytes behind an object URL: it opens
         * and downloads for as long as this tab is open, and goes when the
         * page does — the same bargain as every message typed here.
         */}
        <input
          ref={picker}
          type="file"
          className="sr-only"
          onChange={(e) => {
            const picked = e.target.files?.[0]
            e.target.value = ''
            if (!picked) return
            if (file) URL.revokeObjectURL(file.url)
            setFile({
              name: picked.name,
              size: picked.size,
              url: URL.createObjectURL(picked),
            })
          }}
        />
        <button
          type="button"
          onClick={() => picker.current?.click()}
          title="Attach a file"
          className="text-ink-subtle hover:bg-sunken hover:text-ink mb-0.5 grid size-9 shrink-0 place-items-center rounded-lg"
        >
          <Paperclip
            className="size-4.5"
            strokeWidth={1.9}
            aria-hidden="true"
          />
          <span className="sr-only">Attach a file</span>
        </button>
        <label className="min-w-0 flex-1">
          <span className="sr-only">Message {thread.name}</span>
          <textarea
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            onKeyDown={(e) => {
              // Enter sends, Shift+Enter breaks the line — the shape everyone
              // already has in their fingers from every other messenger.
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault()
                e.currentTarget.form?.requestSubmit()
              }
            }}
            rows={1}
            placeholder={`Type your message to ${first}...`}
            className="text-ink placeholder:text-ink-subtle w-full resize-none border-0 bg-transparent px-1.5 py-2 text-sm focus:outline-none"
          />
        </label>
        <button
          type="submit"
          disabled={empty}
          className="bg-brand-600 hover:bg-brand-700 disabled:bg-brand-300 inline-flex h-10 shrink-0 items-center gap-2 rounded-xl px-4 text-sm font-semibold text-white"
        >
          Send
          <ArrowRight className="size-4" strokeWidth={2.2} aria-hidden="true" />
        </button>
      </div>
    </form>
  )
}

/** "24 KB" — enough to tell a photo from a form before opening it. */
function fileSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`
  if (bytes < 1024 * 1024) return `${Math.round(bytes / 1024)} KB`
  return `${(bytes / 1024 / 1024).toFixed(1)} MB`
}
